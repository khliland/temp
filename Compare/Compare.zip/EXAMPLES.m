%% Two-dimensional X-data
%clear, clc, close all
%{
load spectra
tt = repmat((1:3)',20,1);
ncomp = 10;
Xcal = NIR(tt<3,:);  Ycal = octane(tt<3,:);
Xval = NIR(tt==3,:); Yval = octane(tt==3,:);
B = ncpls(ncomp, Xcal, Ycal);
ypred = (Xval - mean(Xcal,1))*B + mean(Ycal);
RMSEP = zeros(ncomp,size(Yval,2)); R2 = RMSEP;
for i=1:ncomp
    RMSEP(i,:) = sqrt(mean((Yval-ypred(:,i)).^2));
    R2(i,:) = (1 - mean((Yval-ypred(:,i)).^2)./var(Yval))*100;
end
figure
plot(R2(:,1), '-r')
ylabel('R^2')
xlabel('#comp')
grid on
%}


%% Three-dimensional X-data
% clear, clc, close all
if(~isempty(dir('C:\Users\kristl')))
    load('C:\Users\kristl\Dropbox\Datasett\Multiway\sugar.mat')
else
    load('C:\Users\ulfin\Dropbox\Dokumenter\Jobb\Arbeider\Datasett\Multiway\sugar.mat')
end
X = reshape(X,DimX);

ncomp = 10; %20;

% Two responses
Xcal = X(1:2:end,:,:); Ycal = y(1:2:end,1:2);
Xval = X(2:2:end,:,:); Yval = y(2:2:end,1:2);
[B,T,W,Q,R,Wa] = ncpls(ncomp, Xcal, Ycal, [], false);
% [B,T,W,Q,R] = ncplsmem(ncomp, Xcal, Ycal);
Tval = GMP(Xval-mean(Xcal,1), R, 2);  % Predicted scores

% Score plot
figure
plot(T(:,1),T(:,2),'o')
hold on, grid on
plot(Tval(:,1),Tval(:,2),'+')
xlabel('Comp. 1'); ylabel('Comp. 2');
legend('Training','Test')

ypred = GMP(Xval-mean(Xcal,1), B, 2)+reshape(mean(Ycal),[1,1,size(Ycal,2)]); % Predicted responses
RMSEP = zeros(ncomp,size(Yval,2)); R2 = RMSEP; R2cal = RMSEP;
for i=1:ncomp
    RMSEP(i,:) = sqrt(mean((Yval-squeeze(ypred(:,i,:))).^2));
    R2(i,:) = (1 - mean((Yval-squeeze(ypred(:,i,:))).^2)./var(Yval))*100;
    yhat = T(:,1:i)*Q(:,1:i)' + mean(Ycal);             % Fitted values
    R2cal(i,:) = (1 - mean((Ycal-yhat).^2)./var(Ycal))*100;
end

% Two responses & one additional
Xcal = X(1:2:end,:,:); Ycal = y(1:2:end,1:2); YcalAdd = y(1:2:end,3);
Xval = X(2:2:end,:,:); Yval = y(2:2:end,1:2);
%[B,T,W,Q,R] = ncpls(ncomp, Xcal, Ycal, YcalAdd);
[B,T,W,Q,R] = ncpls(ncomp, Xcal, Ycal, YcalAdd, false);
yhat = T*Q' + mean(Ycal);             % Fitted values
T2 = GMP(Xval-mean(Xcal,1), R, 2);    % Predicted scores
ypred = GMP(Xval-mean(Xcal,1), B, 2)+reshape(mean(Ycal),[1,1,size(Ycal,2)]); % Predicted responses
RMSEPc = zeros(ncomp,size(Yval,2)); R2c = RMSEPc;
for i=1:ncomp
    RMSEPc(i,:) = sqrt(mean((Yval-squeeze(ypred(:,i,:))).^2));
    R2c(i,:) = (1 - mean((Yval-squeeze(ypred(:,i,:))).^2)./var(Yval))*100;
end

% Explained variance
figure, hold on
plot(R2cal(:,1), '-k'), plot(R2cal(:,2), '--k')
plot(R2(:,1), '-r'),    plot(R2(:,2), '--r')
plot(R2c(:,1), '-b'),   plot(R2c(:,2), '--b')
ylabel('R^2'), xlabel('#comp')
grid on
legend('Resp. 1, cal.', 'Resp. 2, cal.', 'Resp. 1, val.', 'Resp. 2, val.', 'Resp. 1, Yadd', 'Resp. 2, Yadd','Location','SouthEast')
% legend('Resp. 1, cal.', 'Resp. 2, cal.', 'Resp. 1, val.', 'Resp. 2, val.','Location','SouthEast')


%% Multiway PLS
addpath(genpath('../NPLS'))

[Xfactors,Yfactors,Core,Bm,ypred,ssx,ssy,reg] = npls(Xcal,Ycal,ncomp);
RMSEPa = zeros(ncomp,size(Yval,2)); R2a = RMSEPa;
for i=1:ncomp
    [ypreda,Ta,ssXa,Xresa]=npred(Xval,i,Xfactors,Yfactors,Core,Bm);
    RMSEPa(i,:) = sqrt(mean((Yval-(ypreda)).^2));
    R2a(i,:) = (1 - mean((Yval-(ypreda)).^2)./var(Yval))*100;
end

% Explained variance
figure, hold on
plot(R2a(:,1), '-k'), plot(R2a(:,2), '--k')
plot(R2(:,1), '-r'),  plot(R2(:,2), '--r')
plot(R2c(:,1), '-b'), plot(R2c(:,2), '--b')
ylabel('R^2'), xlabel('#comp')
grid on
legend('NPLS, Resp. 1', 'NPLS, Resp. 2', 'NCPLS, Resp. 1', 'NCPLS, Resp. 2', 'NCPLS-add, Resp. 1', 'NCPLS-add, Resp. 2','Location','SouthEast')


%% Direct use of w or outerproduct of processed w
ncomp = 4;
Xcal = X(1:2:end,:,:); Ycal = y(1:2:end,1:2);
Xval = X(2:2:end,:,:); Yval = y(2:2:end,1:2);

% Process w for each component, e.g. [w1,~,w2] = svds(w,1);
[B,T,W,Q,R,Wa] = ncpls(ncomp, Xcal, Ycal);

% Use w without processing
[Bu,Tu,Wu,Qu,Ru,Wau] = ncpls(ncomp, Xcal, Ycal, [], false);

figure
subplot(221)
plot(W{1}); title('Loading weights, internally processed'); axis tight
subplot(222)
plot(Wu{1}); title('Loading weights, post-processed'); axis tight
subplot(223)
plot(W{2}); title('Loading weights, internally processed'); axis tight
subplot(224)
plot(Wu{2}); title('Loading weights, post-processed'); axis tight
